
from django.shortcuts import render, redirect
from .forms import RuleForm, CombineRulesForm, EvaluateRuleForm
from .models import Rule
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .ast import create_rule, combine_rules, evaluate_rule
from django.core.exceptions import ValidationError

def home(request):
    return render(request, 'rule_engine/home.html')

def create_rule_view(request):
    if request.method == 'POST':
        form = RuleForm(request.POST)
        if form.is_valid():
            rule_string = form.cleaned_data['rule_string']
            ast = create_rule(rule_string)
            Rule.objects.create(rule_string=rule_string, ast_representation=ast.__repr__())
            return redirect('home')
    else:
        form = RuleForm()
    return render(request, 'rule_engine/create_rule.html', {'form': form})

def combine_rules_view(request):
    if request.method == 'POST':
        form = CombineRulesForm(request.POST)
        if form.is_valid():
            selected_rules = form.cleaned_data['rule_ids']
            rule_strings = [rule.rule_string for rule in selected_rules]
            combined_ast = combine_rules(rule_strings)
            return render(request, 'rule_engine/combined_rule.html', {'combined_ast': combined_ast})
    else:
        form = CombineRulesForm()
    return render(request, 'rule_engine/combine_rules.html', {'form': form})

def evaluate_rule_view(request):
    if request.method == 'POST':
        form = EvaluateRuleForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            rule = Rule.objects.first()  # For example, apply the first rule
            ast = rule.ast_representation
            result = evaluate_rule(ast, data)
            return render(request, 'rule_engine/evaluation_result.html', {'result': result})
    else:
        form = EvaluateRuleForm()
    return render(request, 'rule_engine/evaluate_rule.html', {'form': form})



# Create Rule API
@csrf_exempt
def create_rule_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            rule_string = data.get('rule')
            rule_name = data.get('name')

            if not rule_name or not rule_string:
                return JsonResponse({'status': 'error', 'message': 'Rule name and rule string are required.'}, status=400)

            # Create rule object in DB
            rule = Rule(name=rule_name, rule_string=rule_string)
            rule.full_clean()  # Validate rule
            rule.save()

            ast = create_rule(rule_string)  # AST creation as per your logic
            return JsonResponse({'status': 'success', 'ast': str(ast)}, status=200)
        except ValidationError as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)

# Combine Rules API
@csrf_exempt
def combine_rules_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            rules = data.get('rules', [])
            combined_ast = combine_rules(rules)
            return JsonResponse({'status': 'success', 'combined_ast': str(combined_ast)}, status=200)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)

# Evaluate Rule API
@csrf_exempt
def evaluate_rule_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ast = create_rule(data.get('rule'))
            attributes = data.get('attributes')
            result = evaluate_rule(ast, attributes)
            return JsonResponse({'status': 'success', 'result': result}, status=200)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)
