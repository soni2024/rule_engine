import re

class InvalidRuleException(Exception):
    pass

class Node:
    def __init__(self, node_type, value=None, left=None, right=None):
        self.type = node_type
        self.value = value
        self.left = left
        self.right = right

    def __repr__(self):
        if self.type == "operand":
            return f"({self.value})"
        return f"({self.left} {self.value} {self.right})"

def tokenize_rule(rule_string):
    tokens = re.findall(r"\w+|[><=']+|\(|\)|AND|OR", rule_string)
    return tokens

def create_rule(rule_string):
   
    if not isinstance(rule_string, str) or not rule_string:
        raise InvalidRuleException("Rule string is not valid or empty")
    
    if not re.match(r"^[\w\s><=ANDOR'\"()]+$", rule_string):
        raise InvalidRuleException("Rule contains invalid characters or format")

    return {"ast": rule_string}

def parse_expression(tokens):
    if not tokens:
        return None

    token = tokens.pop(0)

    if token == "(":
        left_node = parse_expression(tokens)
        operator = tokens.pop(0)
        right_node = parse_expression(tokens)
        tokens.pop(0)  # Pop the closing ")"
        return Node("operator", operator, left_node, right_node)

    elif token in ["AND", "OR"]:
        return Node("operator", token)

    else:
        return Node("operand", token)

def combine_rules(rules):
    combined_rule = None

    for rule_string in rules:
        current_ast = create_rule(rule_string)
        if combined_rule is None:
            combined_rule = current_ast
        else:
            combined_rule = Node("operator", "AND", combined_rule, current_ast)
    
    return combined_rule

def evaluate_rule(node, data):
    if node is None:
        return False

    if node.type == "operand":
        return evaluate_operand(node.value, data)

    elif node.type == "operator":
        left_value = evaluate_rule(node.left, data)
        right_value = evaluate_rule(node.right, data)

        if node.value == "AND":
            return left_value and right_value
        elif node.value == "OR":
            return left_value or right_value

def evaluate_operand(condition, data):
    field, operator, value = re.split(r'([><=]+)', condition)
    field = field.strip()
    value = value.strip().strip("'")

    if field in data:
        if operator == ">":
            return data[field] > int(value)
        elif operator == "<":
            return data[field] < int(value)
        elif operator == "=":
            return data[field] == value
    return False
